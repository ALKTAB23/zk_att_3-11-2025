# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import resource_calendar_custom
from . import hr_attendance_policy_custom
from . import hr_employee_contract_custom
from . import hr_shift_generate_custom
from . import shifts_requests
from . import attendance_sheet_custom
from . import hr_payroll_custom
from . import leave_custom